from flask import Flask, request, jsonify
from biblioteca.translator import Translator
from biblioteca.learning import DictionaryUpdater
from biblioteca.audio_processor import AudioProcessor  # Supondo que você tenha uma classe para lidar com áudio
import os

app = Flask(__name__)

# Caminhos para os dicionários
FORMAL_DICT_PATH = "biblioteca/dictionary.json"
SLANG_DICT_PATH = "biblioteca/slang_dictionary.json"

# Inicializa tradutor e atualizador de dicionário
translator = Translator(FORMAL_DICT_PATH, SLANG_DICT_PATH)
dictionary_updater = DictionaryUpdater(FORMAL_DICT_PATH, SLANG_DICT_PATH)

# Rota para processar o áudio
@app.route("/process-audio", methods=["POST"])
def process_audio_route():
    if "audio" not in request.files:
        return jsonify({"success": False, "message": "Nenhum arquivo de áudio enviado."}), 400

    audio_file = request.files["audio"]
    audio_path = os.path.join("uploads", audio_file.filename)
    os.makedirs("uploads", exist_ok=True)
    audio_file.save(audio_path)

    try:
        # Processar o áudio com sua biblioteca
        audio_processor = AudioProcessor(audio_path)
        audio_processor.normalize_audio()

        # Reconhecimento de fala (implementar no futuro ou usar placeholder)
        recognized_text = "Texto reconhecido do áudio (placeholder)"  # Simule aqui o resultado do áudio

        # Traduzir texto reconhecido
        translated_text = translator.translate(recognized_text, direction="pt-en")

        # Atualizar dicionários com palavras novas
        dictionary_updater.update_with_user_feedback()

        return jsonify({"success": True, "message": translated_text})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

if __name__ == "__main__":
    os.makedirs("uploads", exist_ok=True)  # Cria pasta para armazenar áudios temporários
    app.run(host="0.0.0.0", port=5000)

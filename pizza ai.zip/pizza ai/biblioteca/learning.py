import json

class DictionaryUpdater:
    def __init__(self, formal_dict_path, slang_dict_path):
        self.formal_dict_path = formal_dict_path
        self.slang_dict_path = slang_dict_path
        self.formal_dict = self._load_dictionary(self.formal_dict_path)
        self.slang_dict = self._load_dictionary(self.slang_dict_path)

    def _load_dictionary(self, file_path):
        """Carrega um dicionário JSON de um arquivo."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return json.load(file)
        except FileNotFoundError:
            print(f"Aviso: {file_path} não encontrado. Criando um novo dicionário.")
            return {"pt-en": {}, "en-pt": {}}

    def _save_dictionary(self, dictionary, file_path):
        """Salva o dicionário atualizado em um arquivo JSON."""
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(dictionary, file, indent=4, ensure_ascii=False)
        print(f"Dicionário salvo em: {file_path}")

    def classify_and_update(self, word, translation, is_slang, direction):
        """
        Classifica a palavra como formal ou gíria e atualiza o dicionário apropriado.
        
        Args:
            word (str): Palavra original.
            translation (str): Tradução da palavra.
            is_slang (bool): Indica se é uma gíria.
            direction (str): Direção da tradução ("pt-en" ou "en-pt").
        """
        if is_slang:
            self.slang_dict[direction][word] = translation
            self._save_dictionary(self.slang_dict, self.slang_dict_path)
        else:
            self.formal_dict[direction][word] = translation
            self._save_dictionary(self.formal_dict, self.formal_dict_path)

    def update_with_user_feedback(self):
        """
        Simula a entrada do usuário para adicionar novas palavras aos dicionários.
        """
        print("Adicione novas palavras ao dicionário.")
        while True:
            word = input("Digite a palavra (ou 'sair' para finalizar): ").strip()
            if word.lower() == "sair":
                break
            translation = input("Digite a tradução: ").strip()
            is_slang = input("É uma gíria? (s/n): ").strip().lower() == "s"
            direction = input("Direção da tradução ('pt-en' ou 'en-pt'): ").strip()

            if direction not in {"pt-en", "en-pt"}:
                print("Direção inválida. Use 'pt-en' ou 'en-pt'.")
                continue

            self.classify_and_update(word, translation, is_slang, direction)

import json
import os

class Translator:
    def __init__(self, dictionary_path="dictionary.json"):
        self.dictionary_path = dictionary_path
        self.dictionary = self._load_dictionary()

    def _load_dictionary(self):
        """Carrega o dicionário JSON."""
        if os.path.exists(self.dictionary_path):
            with open(self.dictionary_path, "r", encoding="utf-8") as file:
                return json.load(file)
        return {}

    def save_dictionary(self):
        """Salva o dicionário atualizado no arquivo JSON."""
        with open(self.dictionary_path, "w", encoding="utf-8") as file:
            json.dump(self.dictionary, file, ensure_ascii=False, indent=4)

    def translate(self, phrase):
        """Traduza uma frase ou palavra."""
        # Verifica se a frase completa está no dicionário
        if phrase in self.dictionary:
            return self.dictionary[phrase]
        
        # Divide a frase em palavras e traduz palavra por palavra
        words = phrase.split()
        translated_words = []
        for word in words:
            translation = self.dictionary.get(word.lower(), word)
            translated_words.append(translation)
        
        return ' '.join(translated_words)

    def add_translation(self, phrase, translation):
        """Adiciona uma nova tradução ao dicionário."""
        self.dictionary[phrase] = translation
        self.save_dictionary()

import json
import os

def create_slang_dictionary(file_path):
    """Cria um arquivo JSON para o dicionário de gírias, se não existir."""
    if not os.path.exists(file_path):
        slang_dict = {
            "pt-en": {},
            "en-pt": {}
        }
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(slang_dict, file, indent=4, ensure_ascii=False)
        print(f"Dicionário de gírias criado em: {file_path}")
    else:
        print(f"O arquivo {file_path} já existe.")

# Caminho para o arquivo slang_dictionary.json
slang_dict_path = "biblioteca/slang_dictionary.json"
create_slang_dictionary(slang_dict_path)
